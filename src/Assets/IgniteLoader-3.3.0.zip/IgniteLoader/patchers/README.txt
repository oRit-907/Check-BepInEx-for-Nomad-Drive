Put preloader patchers here (BepInEx 5 style patchers work).
Patchers in the old BepInEx\patchers folder are loaded too.
