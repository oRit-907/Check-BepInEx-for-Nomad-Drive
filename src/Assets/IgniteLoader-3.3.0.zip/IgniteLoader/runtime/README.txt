Ignite Loader keeps Windows class libraries here, one folder per Unity version (unity-6000.0.73 for Nomad Drive).
They are Mono's class libraries from Unity's public Mono fork, MIT licensed: see unity-6000.0.73\LICENSE-Mono.txt.
If the game updates to a new Unity version, the loader can set up the matching folder from a Unity Editor of that version.
