IGNITE LOADER 3.3.0  (by AkoRit)
===============================================

Ignite Loader (formerly Nomad Loader) is Nomad Drive's own mod loader. It replaces BepInEx: it starts
up, loads mods, runs patchers, handles configs and logs, and ships HarmonyX for
patching. BepInEx is not used.

Mods made for BepInEx still work:
  * BepInEx 5 plugins run on Ignite Loader's own BepInEx-compatible API
    (IgniteLoader\loader\BepInEx.dll - Ignite Loader's code, same API as BepInEx 5,
    same .cfg file format).
  * BepInEx 6 (Unity Mono) plugins are converted to that API automatically
    ("Name.IgniteBIE5.dll" next to the original; the original is never changed).
  * BepInEx 5 preloader patchers run before the game loads.
  * MelonLoader mods (Unity Mono) run on Ignite Loader's own MelonLoader API (see below).
  * IL2CPP plugins and MelonLoader mods are converted to run on Mono when they can (see below).

FOLDERS
  IgniteLoader\plugins     mods go here
  IgniteLoader\patchers    preloader patchers go here
  IgniteLoader\config      mod settings (.cfg); Ignite Loader's own: config\AkoRit\IgniteLoader.cfg
  IgniteLoader\loader      Ignite Loader itself
  IgniteLoader\runtime     Ignite Loader's Windows class libraries (see below)
  Older installs          mods and patchers in BepInEx\, and in Nomad Loader's Mods\ or
                          NomadLoader\ folders, are still loaded (turn off with
                          [Folders] LoadOldFolders = false). Their settings are copied over once,
                          and Nomad Loader's runtime folder is taken over if this one is missing.

FILES
  LogOutput.log              the mod log
  LoaderStatus.txt           start-up runtime check
  CompatibilityReport.txt    what each mod is, and whether it can run
  CompatibilityReport.json   same, for the in-game Mods menu and Check BepInEx

MELONLOADER MODS
MelonLoader mods made for Unity Mono games run too, on Ignite Loader's own MelonLoader API
(IgniteLoader\loader\MelonLoader.dll - Ignite Loader's code with the same API as MelonLoader
0.5 to 0.7; MelonLoader itself is not used or needed).
  IgniteLoader\MelonMods      MelonLoader mods go here
  IgniteLoader\MelonPlugins   MelonLoader plugins go here
  IgniteLoader\UserLibs       libraries MelonLoader mods need (e.g. UniverseLib)
  IgniteLoader\UserData       their settings: UserData\MelonPreferences.cfg, same format as MelonLoader's
Mods in the game's own Mods\ and Plugins\ folders (where MelonLoader keeps them) load too,
unless MelonLoader itself is installed (then they're left to it - don't run both loaders).
IL2CPP MelonLoader mods are converted first (see IL2CPP below). MelonLoader mods start after
the BepInEx plugins, plugins before mods. Settings: [MelonLoader] in IgniteLoader.cfg.

IL2CPP PLUGINS AND MODS
Nomad Drive runs on Unity Mono, but plugins and MelonLoader mods built for IL2CPP games
(BepInEx 6 IL2CPP, Il2CppInterop or the older Unhollower) are converted to run on Mono when the
game starts, like BepInEx 6 plugins: the converted copy is Name.IgniteBIE5.dll next to the
original, and the original isn't changed. IL2CPP plugins go in IgniteLoader\plugins, IL2CPP
MelonLoader mods in IgniteLoader\MelonMods.
Only ones that use nothing beyond what Nomad Drive has are loaded. An IL2CPP plugin made for
another game usually needs that game's code, and some tools call IL2CPP's native functions
directly: those are listed in CompatibilityReport.txt with exactly what they're missing.
Turn conversion off with [Compatibility] EnableIl2CppBackend in IgniteLoader.cfg.

MOD SETTINGS WINDOW (PAGE UP)
Press Page Up in game for a window with every mod's settings: switches, numbers, text,
choices and keys. Changes are saved straight away. Pick another key, or None to turn the
window off, with [SettingsWindow] Key in IgniteLoader\config\AkoRit\IgniteLoader.cfg.

BEPINEX 6 PATCHERS
BepInEx 6 preloader patchers go in IgniteLoader\patchers like BepInEx 5 ones. Ignite Loader
converts them when the game starts (the converted copy is Name.IgniteBIE5.dll next to them;
their own file isn't changed) and runs their TargetAssembly and TargetType methods.

HOT RELOAD (FOR MOD DEVELOPERS)
Off by default: [HotReload] Enabled = true in IgniteLoader.cfg. Put your plugin's DLL in
IgniteLoader\scripts: it loads from memory (the file isn't locked, so you can build over it),
and reloads as soon as the file changes, or press F6 to reload them all. A reload destroys
the old plugin (its OnDestroy runs), removes the Harmony patches its code made, and starts
the new build. A .pdb next to the DLL gives line numbers in errors.

LINUX AND STEAM DECK
Nomad Drive is a Windows game, so on Linux and Steam Deck it runs through Proton. Ignite
Loader runs the same way: install it exactly as on Windows (extract into the game folder).
One extra step, once: Proton uses its own winhttp.dll unless told otherwise, and that would
keep Ignite Loader from starting. In Steam, right-click Nomad Drive > Properties > General >
Launch Options and enter:

    WINEDLLOVERRIDES="winhttp=n,b" %command%

(on Steam Deck, do this in Desktop Mode or from the game's settings > Properties). Start
the game: IgniteLoader\LoaderStatus.txt then shows "Platform : Linux (Proton ...)". If that
file isn't made at all, the launch option is missing or mistyped.

OLD BEPINEX PATHS
Some mods use "BepInEx\..." paths themselves (configs, logs, saves, their own folders).
Ignite Loader sends every read and write of those to the IgniteLoader folder, so no new
BepInEx folder appears:
 - A mod reading or writing a BepInEx\ file gets the IgniteLoader\ file (BepInEx\config\X.cfg
   is IgniteLoader\config\X.cfg). An old file that's only in BepInEx\ is copied into
   IgniteLoader\ the first time a mod uses it, and the IgniteLoader\ copy is used from then on.
 - Saves too: anything a mod saves goes to IgniteLoader\, also for mods still installed in
   BepInEx\plugins (their saves go to IgniteLoader\plugins\<mod>; an existing save is copied
   over first). Their unchanged files (models, textures) are read where the mod is installed.
 - Settings work the other way round as well: a mod looking in IgniteLoader\config for a
   .cfg that's still only in BepInEx\config finds it there.
 - A mod watching BepInEx\config for edits watches IgniteLoader\config.
Turn it off with RedirectBepInExFolder in IgniteLoader\config\AkoRit\IgniteLoader.cfg.

THE GAME'S .NET FILES
Nomad Drive ships stripped .NET class libraries that can't run a mod loader.
Ignite Loader never uses, restores or copies them. It brings its own Windows class
libraries for the game's exact Unity version (IgniteLoader\runtime\unity-6000.0.73,
Mono's MIT-licensed class libraries from Unity's public Mono fork) and tells Unity's
Mono runtime to load those first. If the game moves to a new Unity version, the
loader can set the new ones up from a Unity Editor of that version, or an Ignite Loader
update brings them. Ignite Loader never downloads anything.

UNINSTALL
Delete winhttp.dll, doorstop_config.ini, .doorstop_version and the IgniteLoader
folder. No game file is changed.

Unity Doorstop (winhttp.dll) by NeighTools, HarmonyX/MonoMod/Mono.Cecil/Tomlet by their
authors - see their licences. Everything else is Ignite Loader.

CREDITS
Unity Doorstop, HarmonyX, MonoMod, Mono.Cecil, Tomlet and Mono's class libraries are by their authors,
under their own licences: see THIRD-PARTY-NOTICES.txt and the licenses folder.
