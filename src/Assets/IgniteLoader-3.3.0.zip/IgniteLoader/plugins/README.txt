Put mods (plugins) here.
BepInEx 5 and BepInEx 6 (Mono) plugins both work with Ignite Loader.
Mods in the old BepInEx\plugins folder are loaded too.
After each launch, IgniteLoader\CompatibilityReport.txt lists what loaded.
